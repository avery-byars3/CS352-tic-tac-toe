package Project2;

public class TicTacToeModel 
{

    private Mark[][] board;
    private boolean xTurn;
    private int size;

    public enum Mark 
    {

        X("X"),
        O("O"),
        EMPTY(" ");

        private String symbol;

        private Mark(String s) 
        {
            symbol = s;
        }

        @Override
        public String toString() 
        {
            return symbol;
        }

    };

    public enum Result 
    {

        X("X"),
        O("O"),
        TIE("TIE"),
        NONE("NONE");

        private String symbol;

        private Result(String s) 
        {
            symbol = s;
        }

        @Override
        public String toString() 
        {
            return symbol;
        }

    };

    public TicTacToeModel() 
    {
        this(TicTacToe.DEFAULT_SIZE);
    }

    public TicTacToeModel(int size) 
    {
        xTurn = true;

        board = new Mark[size][size];

        for (int r = 0; r < board.length; r++) 
        {
            for (int c = 0; c < board[r].length; c++) 
            {
                board[r][c] = Mark.EMPTY;
            }
        }
    }

    public boolean makeMark(int row, int col) 
    {
        if (!isValidSquare(row, col)) 
        {
            return false;
        }

        if (isSquareMarked(row, col)) 
        {
            return false;
        }

        if (xTurn) 
        {
            board[row][col] = Mark.X;
            xTurn = false;
        } 
        else 
        {
            board[row][col] = Mark.O;
            xTurn = true;
        }

        return true;
    }

    private boolean isValidSquare(int row, int col) 
    {
        return row >= 0 && row < board.length && col >= 0 && col < board[row].length;
    }

    private boolean isSquareMarked(int row, int col) 
    {
        return board[row][col] != Mark.EMPTY;
    }

    public Mark getMark(int row, int col) 
    {
        return board[row][col];
    }

    public Result getResult() 
    {
        if (isTie()) {
            return Result.TIE;
        }

        if (isMarkWin(Mark.X)) 
        {
            return Result.X;
        }

        if (isMarkWin(Mark.O)) 
        {
            return Result.O;
        }

        return Result.NONE;
    }

    private boolean isMarkWin(Mark mark) 
    {
        for (int r = 0; r < board.length; r++) 
        {
            boolean allSlotsMatched = true;

            for (int c = 0; c < board[r].length; c++) 
            {
                if (board[r][c] != mark) 
                {
                    allSlotsMatched = false;
                    break;
                }
            }

            if (allSlotsMatched) 
            {
                return true;
            }
        }

        for (int c = 0; c < board[0].length; c++) 
        {
            boolean allSlotsMatched = true;

            for (int r = 0; r < board.length; r++) 
            {
                if (board[r][c] != mark) 
                {
                    allSlotsMatched = false;
                    break;
                }
            }

            if (allSlotsMatched) 
            {
                return true;
            }
        }

        boolean allSlotsMatched = true;

        for (int i = 0; i < board.length; i++) 
        {
            if (board[i][i] != mark) 
            {
                allSlotsMatched = false;
                break;
            }
        }

        if (allSlotsMatched) 
        {
            return true;
        }

        allSlotsMatched = true;

        for (int r = 0, c = board[r].length - 1; r < board.length; r++, c--) 
        {
            if (board[r][c] != mark) 
            {
                allSlotsMatched = false;
                break;
            }
        }

        return allSlotsMatched;
    }

    private boolean isTie() 
    {
        for (int r = 0; r < board.length; r++) 
        {
            for (int c = 0; c < board[r].length; c++) 
            {
                if (board[r][c] == Mark.EMPTY) 
                {
                    return false;
                }
            }
        }

        return !isMarkWin(Mark.X) && !isMarkWin(Mark.O);
    }

    public boolean isGameover() 
    {
        return getResult() != Result.NONE;
    }

    public boolean isXTurn() 
    {
        return xTurn;

    }

    public int getSize()
    {
        return size;
    }
}

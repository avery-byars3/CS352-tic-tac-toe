package Project2;

import javax.swing.*;

public class TicTacToe 
{

    public static final int DEFAULT_SIZE = 3;

    public static void main(String[] args) 
    {

        int size = DEFAULT_SIZE;
      
        if (args.length > 0) 
        {
            size = Integer.parseInt(args[0]);
        }
        
        TicTacToeController controller = new TicTacToeController(size);

        JFrame win = new JFrame("Tic-Tac-Toe");
        win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        win.add(controller.getView());
        win.pack();
        win.setVisible(true);
    }
}
